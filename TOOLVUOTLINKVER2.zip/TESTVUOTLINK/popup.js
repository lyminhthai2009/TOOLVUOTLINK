const getPayload = () => {
    const p = new URLSearchParams();
    p.append('screen', '1280 x 720');
    p.append('browser[name]', 'Chrome');
    p.append('browser[version]', '146.0.0.0');
    p.append('browser[majorVersion]', '146');
    p.append('os[name]', 'Windows');
    p.append('os[version]', '10.0');
    p.append('mobile', 'false');
    p.append('cookies', 'true');
    return p.toString();
};

// --- LUỒNG CHÍNH CHẠY TRÊN TRANG WEB ---
async function runUltimateFlow(payloadStr) {
    if (!document.getElementById('tool-log-window')) {
        const logWin = document.createElement('div');
        logWin.id = 'tool-log-window';
        logWin.innerHTML = `<div style="background:#000; color:#0f0; position:fixed; bottom:20px; left:20px; width:260px; z-index:999999; border:1px solid #0f0; font-family:monospace; padding:10px; box-shadow:0 0 15px #0f0;">
            <div style="border-bottom:1px solid #0f0; margin-bottom:8px; font-weight:bold; display:flex; justify-content:space-between;">
                <span>GHOST SMART V14.1</span>
                <span onclick="this.parentElement.parentElement.remove()" style="cursor:pointer">✖</span>
            </div>
            <div id="log-msg">Đang check tiến trình...</div>
            <div id="log-timer" style="font-size:28px; color:yellow; text-align:center; margin:10px 0;">--s</div>
        </div>`;
        document.body.appendChild(logWin);
    }

    const log = (m) => { document.getElementById('log-msg').innerText = m; };
    const timerDisplay = document.getElementById('log-timer');
    const token = window.rd || "";
    
    if (!token) {
        log("❌ Chờ window.rd...");
        return { status: "error", msg: "no_token" };
    }

    const headers = { 'content-value-random': token };
    const payload = new URLSearchParams(payloadStr);

    // HÀM VÒNG LẶP (KHÔNG DÙNG LOCATION.RELOAD)
    async function bypassCycle() {
        try {
            log("📡 Đang lấy Job...");
            let jobRes = await fetch('https://uptolink.one/check/job', { method: 'POST', headers, body: payload }).then(r => r.json());
            
            let timeLeft = (jobRes.wait !== undefined) ? jobRes.wait : 60;

            log("📡 Gửi Countdown...");
            await fetch('https://uptolink.one/check/countdown', { method: 'POST', headers, body: payload });

            // ĐỒNG HỒ ĐẾM NGƯỢC VẪN CHẠY BÌNH THƯỜNG (1000ms = 1s/nhịp)
            let interval = setInterval(async () => {
                if (timeLeft > 0) {
                    timerDisplay.innerText = timeLeft + "s";
                    timeLeft--;
                } else {
                    clearInterval(interval);
                    timerDisplay.innerText = "🚀 GỬI!";
                    
                    // DELAY GIỮA CÁC BƯỚC GIẢM 1/10 (Gốc là 1200-2200ms -> Nay chỉ còn 120-220ms)
                    const randomDelay = Math.floor(Math.random() * 100) + 120;
                    log(`🕒 Chờ ${randomDelay}ms...`);

                    setTimeout(async () => {
                        log("📡 Gửi Continue...");
                        let res = await fetch('https://uptolink.one/check/continue', { method: 'POST', headers, body: payload }).then(r => r.json());
                        
                        if (res && res.url) {
                            log("✅ THÀNH CÔNG!");
                            window.location.href = res.url;
                        } else {
                            log("🔄 Lỗi/Chưa xong. Lặp lại Job...");
                            // DELAY CHỜ VÒNG LẶP MỚI GIẢM 1/10 (Gốc là 2000ms -> Nay chỉ còn 200ms)
                            setTimeout(bypassCycle, 200);
                        }
                    }, randomDelay); // Sử dụng thời gian chờ đã giảm 1/10
                }
            }, 1000); // <-- Trả về 1000ms chuẩn ở đây

        } catch (e) {
            log("❌ Lỗi kết nối. Thử lại...");
            // Delay khi lỗi mạng cũng làm ngắn lại
            setTimeout(bypassCycle, 300); 
        }
    }

    // Kích hoạt chu trình lần đầu tiên
    bypassCycle();
    
    return { status: "running" };
}

// --- QUẢN LÝ EVENT TRÊN POPUP ---
document.getElementById('btn-start').addEventListener('click', async () => {
    chrome.storage.local.set({ isRunning: true });
    startTheMachine();
});

document.getElementById('btn-stop').addEventListener('click', () => {
    chrome.storage.local.set({ isRunning: false });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.reload(tabs[0].id);
    });
});

async function startTheMachine() {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: runUltimateFlow,
        args: [getPayload()]
    });
}

// Tự động chạy lại khi load trang
chrome.storage.local.get(['isRunning'], (res) => {
    if (res.isRunning) {
        setTimeout(startTheMachine, 1500);
    }
});